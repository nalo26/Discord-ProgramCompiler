public class Calc {

    public int x;
    public int y;
    
    public Calc(int a, int b) {
        this.x = a;
        this.y = b;
    }

    public int calc(){
        return this.x + this.y;
    }

}